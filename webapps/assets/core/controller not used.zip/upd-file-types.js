var updFiletypes = {
    isProcessing: ko.observable(false),
    istypeFile: ko.observableArray([]),
    isfieldSeparator: ko.observableArray([]),
    isupdateUser: ko.observableArray([]),

    FilterFiletype: ko.observableArray([]),
    FilterfieldSeparator: ko.observableArray([]),
    Filterupdateuser: ko.observableArray([]),
};

updFiletypes.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

updFiletypes.getDataGridUpdFileType = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatfileTypes/getdata";
    $("#MasterGridUpdFileTypes").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [
                {
                    field:"Filetype",
                    title:"Clearer Number",
                    width:100
                },
                {
                    field:"Refid",
                    title:"Clearer Name",         
                    width:100
                },
                {
                    field:"Fieldseparator",
                    title:"Description",
                    width:100
                },
                {
                    field:"Sampleline",
                    title:"Update User",
                    width:200
                },
                {
                    field:"Updateuser",
                    title:"Update User",
                    width:100
                },
                {
                    field:"Startline",
                    title:"Startline",
                    width:100,
                    attributes: {"class": "align-right"}
                },
                {
                    field:"Datecreated",
                    title:"Date Created",
                    width:100,
                    template:"#= moment(Datecreated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                },
                {
                    field:"Dateupdated",
                    title:"Date Updated",
                    width:100,
                    template:"#= moment(Dateupdated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
   updFiletypes.getDataGridUpdFileType();
});