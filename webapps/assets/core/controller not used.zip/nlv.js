var nlv = {
    isProcessing: ko.observable(false),
    isAccountNumber: ko.observableArray([]),
    isBaseCurrency: ko.observableArray([]),

    FilterAccountNumber : ko.observableArray([]),
    FilterBaseCurrency : ko.observableArray([]),

    tradeDateFrom : ko.observable(),
    tradeDateTo : ko.observable(),
};

nlv.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

nlv.getDataGridNlv = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatnlv/getdata";
    $("#MasterGridNlv").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [
                {
                    field:"Accountnumber",
                    title:"Account Number",
                    width:100
                },
                {
                    field:"Basecurrency",
                    title:"Base Currency",         
                    width:100
                },
                {
                    field:"Nlvtd",
                    title:"Description",
                    width:100
                },
                {
                    field:"Nlvtd1",
                    title:"Nlv Td",
                    width:100
                },
                {
                    field:"Nlvtd2",
                    title:"Nlv Td2",
                    width:100
                },
                {
                    field:"Nlvtd3",
                    title:"Nlv Td3",
                    width:100
                },
                {
                    field:"Nlvtd4",
                    title:"Update User",
                    width:100
                },
                {
                    field:"Nlvtd4",
                    title:"Nlvtd4",
                    width:100
                },
                {
                    field:"Nlvdiff2",
                    title:"Nlv Diff2",
                    width:100
                },
                {
                    field:"Nlvdiff3",
                    title:"Nlv Diff3",
                    width:100
                },
                {
                    field:"Nlvdiff4",
                    title:"Nlv Diff4",
                    width:100
                },
                {
                    field:"Tradedate",
                    title:"Trade Date",
                    width:100,
                    template:"#= moment(Tradedate).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
   nlv.getDataGridNlv();
    $("#TradeDateFrom").kendoDatePicker({
        format: "MMM dd , yyyy",
    }).data("kendoDatePicker");
    $("#TradeDateFrom").closest("span.k-datepicker").width(130);

    $("#TradeDateTo").kendoDatePicker({
        format: "MMM dd , yyyy",
    }).data("kendoDatePicker");
    $("#TradeDateTo").closest("span.k-datepicker").width(130);
});