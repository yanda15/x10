var updMappingFields = {
    isProcessing: ko.observable(false),
    istypeFile: ko.observableArray([]),
    FiltertypeFile : ko.observableArray([]),
};

updMappingFields.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

updMappingFields.getDataGridUpdMappingFields = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatupdmappingfields/getdata";
    $("#MasterGridUpdMappingFields").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [

                {
                    field:"Filetype",
                    title:"File Type",
                    width:100
                },
                {
                    field:"Cemonformat",
                    title:"Ce Month Format",         
                    width:100
                },
                {
                    field:"Ceyearformat",
                    title:"Ce Year Format",
                    width:100
                },
                {
                    field:"Tddayformat",
                    title:"Td Day Format",
                    width:100
                },
                {
                    field:"Updateuser",
                    title:"Update User",
                    width:100
                },
                {
                    field:"Tdmonformat",
                    title:"Td Month Format",
                    width:100
                },
                {
                    field:"Tdyearformat",
                    title:"Td Year Format",
                    width:100
                },
                {
                    field:"Seqnum",
                    title:"Seq Number",
                    width:100
                },
                {
                    field:"Exchange",
                    title:"Exchange",
                    width:100
                },
                {
                    field:"Contractcode",
                    title:"Contract Code",
                    width:100
                },
                {
                    field:"Contractexpiry",
                    title:"Contract Expiry",
                    width:100
                },
                {
                    field:"Buyorsell",
                    title:"Buy Or Sell",
                    width:100
                },
                {
                    field:"Quantity",
                    title:"Quantity",
                    width:100
                },
                {
                    field:"Tradeprice",
                    title:"Trade Price",
                    width:100
                },
                {
                    field:"Producttype",
                    title:"Product Type",
                    width:100
                },
                {
                    field:"Accountnumber",
                    title:"Account Number",
                    width:100
                },
                {
                    field:"Tradedate",
                    title:"Trade Date",
                    width:100
                },
                {
                    field:"Transactiontime",
                    title:"Transaction Time",
                    width:100
                },
                {
                    field:"Cemonstart",
                    title:"Ce Month Start",
                    width:100
                },
                {
                    field:"Ceyearstart",
                    title:"Ce Year Start",
                    width:100
                },
                {
                    field:"Tddaystart",
                    title:"Td Day Start",
                    width:100
                },
                {
                    field:"Tdmonstart",
                    title:"Td Month Start",
                    width:100
                },
                {
                    field:"Tdyearstart",
                    title:"Td Year Start",
                    width:100
                },
                {
                    field:"DateUpdated",
                    title:"Date Updated",
                    width:100,
                    template:"#= moment(DateUpdated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
   updMappingFields.getDataGridUpdMappingFields()
});