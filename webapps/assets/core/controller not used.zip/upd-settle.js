var updSettle = {
    isProcessing: ko.observable(false),
    istypeFile: ko.observableArray([]),
    isContractMap: ko.observableArray([]),
    isUpdContract: ko.observableArray([]),
    isUpdateuser: ko.observableArray([]),

    FilterFiletype : ko.observableArray([]),
    FilterContractMap : ko.observableArray([]),
    FilterUpdContract : ko.observableArray([]),
    FilterUpdateuser : ko.observableArray([]),
};

updSettle.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

updSettle.getDataGridUpdSettle = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatupdsettle/getdata";
    $("#MasterGridUpdSettle").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [  
                {
                    field:"Filetype",
                    title:"File Type",
                    width:100
                },
                {
                    field:"ContractMap",
                    title:"Contract Map",         
                    width:100
                },
                {
                    field:"UpdateUser",
                    title:"Update User",
                    width:100
                },
                {
                    field:"UpdDivisor",
                    title:"Upd Divisor",
                    width:100,
                    attributes: {"class": "align-rigth"}
                }
            ]
    });
}

$(document).ready(function() {
   updSettle.getDataGridUpdSettle();
});