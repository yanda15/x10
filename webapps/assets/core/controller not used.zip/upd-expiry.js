var updexpiry = {
    isProcessing: ko.observable(false),
    istypeFile: ko.observableArray([]),
    iscodeContract: ko.observableArray([]),
    isexpiryTprs: ko.observableArray([]),
    isupdExpiry: ko.observableArray([]),
    isupdUser: ko.observableArray([]),

    FilterFiletype : ko.observableArray([]),
    FilterContractCode : ko.observableArray([]),
    FilterTprsexpiry : ko.observableArray([]),
    Filterupdexpiry : ko.observableArray([]),
    FilterUpdateuser : ko.observableArray([]),
};

updexpiry.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

updexpiry.getDataGridupdExpiry = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatupdexpiry/getdata";
    $("#MasterGridExpiry").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [
                {
                    field:"Contractcode",
                    title:"Contract Code",
                    width:100
                },
                {
                    field:"Tprsexpiry",
                    title:"Tprs Expiry",         
                    width:100
                },
                {
                    field:"Updexpiry",
                    title:"Upd Expiry",
                    width:100
                },
                {
                    field:"Updateuser",
                    title:"Update User",
                    width:100
                },
                {
                    field:"DateUpdated",
                    title:"Date Updated",
                    width:100,
                    template:"#= moment(DateUpdated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
   updexpiry.getDataGridupdExpiry();
});