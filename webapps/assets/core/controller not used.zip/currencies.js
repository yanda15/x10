var currencies = {
    isProcessing: ko.observable(false),

    filterCurrencyCoder : ko.observable(""),
    filterDescription : ko.observable(""),
};

currencies.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

currencies.searchData = function(){
    currencies.getDataGridCurrencies();
}

currencies.resetData = function(){
    currencies.filterCurrencyCoder("");
    currencies.filterDescription("");
    currencies.getDataGridCurrencies();
}

currencies.getDataGridCurrencies = function(){
    var param =  {
        CurrencyCode :currencies.filterCurrencyCoder(),
        Description : currencies.filterDescription()
    };
    
    var dataSource = [];
    var url = "/mastercurrency/getdata";
    $("#MasterGridCurrencies").html("");
    $("#MasterGridCurrencies").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            if (data.Data.Count == 0) {
                                return dataSource;
                            } else {
                                return data.Data.Records;
                            }
                        },
                        total: "Data.Count",
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: true,
            columns: [
                {
                    field:"Currency_code",
                    title:"Currency Code",
                    width:100
                },
                {
                    field:"Description",
                    title:"Description",
                    width:100
                },
                {
                    field:"Date_created",
                    title:"Date Created",
                    width:150,
                    attributes: {"class": "align-center"},
                    // template:"#= moment(DateCreated).format('MMMM DD , YYYY') #"
                },
                {
                    field:"Date_updated",
                    title:"Date Updated",
                    width:150,
                    attributes: {"class": "align-center"},
                    // template:"#= moment(DateUpdated).format('MMMM DD , YYYY') #"
                },
                {
                    field:"Update_user",
                    title:"Update User",
                    width:110
                }
            ]
    });
}

$(document).ready(function() {
   currencies.getDataGridCurrencies();
});