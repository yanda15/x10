var contractsExpiry = {
    isProcessing: ko.observable(false),
    isUpdateUser: ko.observableArray([]),
    FilterUpdateUser: ko.observableArray([]),

    expiryDatestart : ko.observable(),
    expiryDateend : ko.observable(),

    firstNoticeDaystart : ko.observable(),
    firstNoticeDayend : ko.observable(),

    lastTradingDaystart : ko.observable(),
    lastTradingDayend : ko.observable(),
};

contractsExpiry.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

contractsExpiry.getDataGridContractsExpiry = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatcontractsexpiry/getdata";
    $("#MasterGridContractsExpiry").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [
                {
                    field:"ClearerNumber",
                    title:"Clearer Number",
                    width:100
                },
                {
                    field:"ClearerName",
                    title:"Clearer Name",         
                    width:100
                },
                {
                    field:"ClearerDescription",
                    title:"Description",
                    width:100
                },
                {
                    field:"UpdateUser",
                    title:"Update User",
                    width:100
                },
                {
                    field:"DateUpdated",
                    title:"Date Updated",
                    width:100,
                    template:"#= moment(DateUpdated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
   contractsExpiry.getDataGridContractsExpiry();
    $("#expiryDatestart").kendoDatePicker({
        format: "MMM dd , yyyy",
    }).data("kendoDatePicker");
    $("#expiryDatestart").closest("span.k-datepicker").width(130);

    $("#expiryDateend").kendoDatePicker({
        format: "MMM dd , yyyy",
    }).data("kendoDatePicker");
    $("#expiryDateend").closest("span.k-datepicker").width(130);

    $("#firstNoticeDaystart").kendoDatePicker({
        format: "MMM dd , yyyy",
    }).data("kendoDatePicker");
    $("#firstNoticeDaystart").closest("span.k-datepicker").width(130);

    $("#firstNoticeDayend").kendoDatePicker({
        format: "MMM dd , yyyy",
    }).data("kendoDatePicker");
    $("#firstNoticeDayend").closest("span.k-datepicker").width(130);
});