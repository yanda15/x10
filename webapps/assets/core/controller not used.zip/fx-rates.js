var fxRates = {
    isProcessing: ko.observable(false),
    isFirstLoad : ko.observable(true),
    ExchangeNames: ko.observableArray([]),
    FilterExchangeName: ko.observableArray([]),
    FilterIMin : ko.observable(),
    FilterITime : ko.observable(),
    FilterCurrencyId : ko.observable(0),
};

fxRates.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

fxRates.getDataGridFxrate = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatfxrates/getdata";
    $("#MasterGridFxRates").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [
                {
                    field:"Month",
                    title:"Month",
                    width:100
                },
                {
                    field:"UpdateUser",
                    title:"Update User",         
                    width:100
                },
                {
                    field:"Year",
                    title:"Year",
                    width:100
                },
                {
                    field:"CurrencyId",
                    title:"Currency Id",
                    width:100
                },
                {
                    field:"Rate",
                    title:"Rate",
                    width:100
                },
                {
                    field:"DateCreated",
                    title:"Date Created",
                    width:100,
                    template:"#= moment(DateCreated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                },
                {
                    field:"DateUpdated",
                    title:"Date Updated",
                    width:100,
                    template:"#= moment(DateUpdated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
   fxRates.getDataGridFxrate();
});