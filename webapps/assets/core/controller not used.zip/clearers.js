var clearer = {
    isProcessing: ko.observable(false),
    isFirstLoad: ko.observable(true),

    isClearerName: ko.observableArray([]),
    isClearerNumber: ko.observableArray([]),
    isUpdateUser: ko.observableArray([]),

    FilterClearerName: ko.observableArray([]),
    FilterClearerNumber: ko.observableArray([]),
    FilterUpdateUser: ko.observableArray([]),
    DateUpdated: ko.observable(""),
};

clearer.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

clearer.getDataGridClearer = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatclearers/getdata";
    $("#MasterGridClearers").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [
                {
                    field:"ClearerNumber",
                    title:"Clearer Number",
                    width:100
                },
                {
                    field:"ClearerName",
                    title:"Clearer Name",         
                    width:100
                },
                {
                    field:"ClearerDescription",
                    title:"Description",
                    width:100
                },
                {
                    field:"UpdateUser",
                    title:"Update User",
                    width:100
                },
                {
                    field:"DateUpdated",
                    title:"Date Updated",
                    width:100,
                    template:"#= moment(DateUpdated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
    $("#DateUpdated").kendoDatePicker({
        format: "MMMM dd , yyyy",
    }).data("kendoDatePicker");
   clearer.getDataGridClearer();
});