var updExchange = {
    isProcessing: ko.observable(false),
    istypeFile: ko.observableArray([]),
    isExchangeName: ko.observableArray([]),
    isUpdExchangeName: ko.observableArray([]),
    isUpdateuser: ko.observableArray([]),

    FilterFiletype: ko.observableArray([]),
    FilterExchangeName: ko.observableArray([]),
    FilterUpdExchangeName: ko.observableArray([]),
    FilterUpdateuser: ko.observableArray([]),
};

updExchange.backMenuMaster = function(){
    window.location.href = "/datamaster/default";
}

updExchange.getDataGridUpdExchange = function(){
    var param =  {
    };
    var dataSource = [];
    var url = "/flatexchange/getdata";
    $("#MasterGridUpdExchange").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            console.log(data);
                            // if (data.data.Total == 0) {
                            //     return dataSource;
                            // } else {
                            //     return data.data.Data;
                            // }
                        },
                        total: 1,
                    },
                    pageSize: 15,
                    serverPaging: true, // enable server paging
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
            columns: [
                {
                    field:"Filetype",
                    title:"File Tepe",
                    width:100
                },
                {
                    field:"Exchangename",
                    title:"Exchange Name",         
                    width:100
                },
                {
                    field:"Updexchangename",
                    title:"Upd Exchange Name",
                    width:100
                },
                {
                    field:"Updateuser",
                    title:"Update User",
                    width:100
                },
                {
                    field:"Dateupdated",
                    title:"Date Updated",
                    width:100,
                    template:"#= moment(DateUpdated).format('MMMM DD , YYYY') #",
                    attributes: {"class": "align-center"}
                }
            ]
    });
}

$(document).ready(function() {
   updExchange.getDataGridUpdExchange();
});